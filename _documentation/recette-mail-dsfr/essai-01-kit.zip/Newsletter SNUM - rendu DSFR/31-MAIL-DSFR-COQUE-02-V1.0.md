SNUM_MAIL_DSFR_COQUE_02_START
```html
th:100%; max-width:600px; margin:0 auto; background-color:#ffffff; border:1px solid #e5e5e5;">
          <tr><td class="surface content-pad brand-rule" bgcolor="#ffffff" style="font-family:'Marianne',Arial,Helvetica,sans-serif; padding:24px 40px; border-top:3px solid #000091; background-color:#ffffff;">
            <p class="text-main" style="font-family:'Marianne',Arial,Helvetica,sans-serif; margin:0; color:#161616; font-size:14px; line-height:22px; font-weight:700;">SERVICE DU NUMÉRIQUE (SNUM)</p>
          </td></tr>
          <tr><td class="title-bg content-pad" bgcolor="#ececfe" style="font-family:'Marianne',Arial,Helvetica,sans-serif; padding:28px 40px 30px; background-color:#ececfe;">
            <h1 class="mail-title text-main" style="font-family:'Marianne',Arial,Helvetica,sans-serif; margin:0 0 12px; color:#161616; font-size:32px; line-height:40px; font-weight:700;">REVUE DE PRESSE</h1>
            <p class="text-muted" style="font-family:'Marianne',Arial,Helvetica,sans-serif; margin:0; color:#3a3a3a; font-size:14px; line-height:22px;">Édition du @@EDITION_LONG@@</p>
          </td></tr>
          <tr><td class="surface content-pad" bgcolor="#ffffff" style="font-family:'Marianne',Arial,Helvetica,sans-serif; padding:28px 40px 20px; background-color:#ffffff;">
            <p class="text-muted" style="font-family:'Marianne',Arial,Helvetica,sans-serif; margin:0 0 8px; color:#3a3a3a; font-size:16px; line-height:24px;">@@INTRO@@</p>
            <p class="text-muted" style="font-family:'Marianne',Arial,Helvetica,sans-serif; margin:0 0 8px; color:#3a3a3a; font-size:16px; line-height:24px;">Bonne lecture&nbsp;!</p>
          </td></tr>

@@RUBRICS@@
@@WATCH@@
          <tr><td class="footer-bg content-pad" bgcolor="#f5f5fe" style="font-family:'Marianne',Arial,Helvetica,sans-serif; padding:24px 40px; background-color:#f5f5fe;">
            <p class="text-muted" style="font-family:'Marianne',Arial,Helvetica,sans-serif; margin:0 0 6px; color:#666666; font-size:13px; line-height:21px; font-weight:700;">Revue de presse · Diffusion deux fois par semaine</p>
            <p class="text-muted" style="font-family:'Marianne',Arial,Helvetica,sans-serif; margin:0; color:#666666; font-size:13px; line-height:21px;">Document à usage interne</p>
          </td></tr>
          <tr><td class="surface content-pad" bgcolor="#ffffff" style="font-family:'Marianne',Arial,Helvetica,sans-serif; padding:28px 40px; background-color:#ffffff;">
            <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100%;">
              <tr>
                <td class="signature-image" width="147" valign="top" style="font-family:'Marianne',Arial,Helvetica,sans-serif; width:147px; vertical-align:top;">
                  <div style="font-family:'Marianne',Arial,Helvetica,sans-serif; display:inline-block; padding:8px; background-color:#ffffff;"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAI4AAAA/CAIAAAC5CWePAAAjB0lEQVR4nO18WXNc13XuOvPpPj3PQE+YSQAECQIkJFIkTNlkQtG05DiJX5LHVKVSdf9RElVclfuguqpIkWTLEk2KswiQBEECJIBGY+wGutHzdObpPqyoLy05t2JFpEoO1wMKODjd5+y99l7Dt761ic8/W13fkBSNsSwgaYogCNM0wTIp0iAJjWeN/qR/dCSe7PEAb7UK23vPltytNq9otAEM0KRN6jYoDK3zbGh0hOtLgEuwCdICwgYSLJsmKXgl34XQX1z78vrtA1Fy6oZF0zRBEKapg62zlMFQytTkQDJ6ysn5gAKwQel08plVOrPqarUJ3WKABZtWbFBYTnE7jzBE3CuA0wEEAMlYAJYFFAnE9z3IPw2ht7dLmUyz1bF0TadomiQJ29QJUDlaD/pp/2xqfHQ4GAEwAMBkGcZFQSe3YdYbtmrYwNoWLQMp8YLsc2uVMsgSmCZBEiQJFpBgf9/j+xMSmgQHYcq2xoBJ2BZtUmCbNpAmQZqhWCKSSHrDAAQYOtAc4fG43IJDMXRGlSxFo23KtCnCJmhCJxWCNjUgCLAJsAkCSBLAsm3CJl5tq+9ESIYULEWmTZEDnSVV2+gAKAwLFmV0LFEE1eRBZcBygKXLJmW7g37WF7B4h07YFm3QrMoyMkXJLK3RJACQYFBAcGABaMBRBFgA1h/YXLb9asf9cUIrssVyLlGmdVsH07IBnLzgDwusM+DxsJZliCJ4eaAZAJslddrLOWuMQBC8YRKEZZKUTYJNmLqpqaQNABTYBFgAuK0IANsCgsSHoXoIguj+fCX/daGBZgzGo9I86DoQQNOE2yfEIgG3DziuY4uKVACKBeAAVBGaLZ8JHoWyVYbSGJIgGBpsijBsRjFpMAEsEmwSbAASLAJIANuySIIEANu2uzvplZ6+hdAWoXd0FSwWwAYAwzJkRWrUTUM1ObZV2WPr+yndF2Udirj+tLyzqmY3pVqHFkHTGYaiCNI2SMIgOItkNROAIIAmAR0WgAkAJEEAEAAEQbzS0H
```
SNUM_MAIL_DSFR_COQUE_02_END
