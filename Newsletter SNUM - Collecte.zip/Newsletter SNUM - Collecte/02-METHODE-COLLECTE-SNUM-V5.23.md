`SNUM_COLLECTE_V523_METHODE_START`

# Méthode Collecte autonome

## 1. Exécuter le cycle Web

Lance immédiatement une recherche Web composite dans le Projet Collecte à partir de
`DATE_EDITION` et de `PERIODE`. Termine la recherche et produis le paquet dans cette
même réponse. N’affiche jamais de requête à recopier, de plan, de trace ou de commande
intermédiaire.

La recherche couvre ensemble `numerique`, `ia`, `commande`, `rh` et `bercy`, avec
les cinq axes complets du prompt.

Avant toute recherche générale, lance les quatre recherches groupées ci-dessous,
une par groupe. Chaque requête nomme explicitement les domaines du groupe et la
période en toutes lettres :

- `G1` presse numérique : `next.ink`, `01net.com`, `journaldunet.com`,
  `itforbusiness.fr`, `lemonde.fr` ;
- `G2` action publique : `numerique.gouv.fr`, `modernisation.gouv.fr`,
  `vie-publique.fr`, `acteurspublics.fr` ;
- `G3` Bercy : `economie.gouv.fr`, `presse.economie.gouv.fr`,
  `picsel.alize.finances.rie.gouv.fr` ;
- `G4` régulation : `cnil.fr`, `legifrance.gouv.fr`.

Ouvre les résultats de ces quatorze domaines avant ceux des autres sites, puis
complète avec d’autres sources fiables. Un domaine inaccessible ou sans
publication dans la fenêtre n’est pas une panne : poursuis avec les autres.

Ouvre les résultats avant de les retenir. Le Web
reste actif pendant tout ce cycle ; le métier ne copie aucune réponse entre deux
chats et n’envoie aucune commande de continuation ou de normalisation.

## 2. Vérifier et normaliser les sources

Une source valide possède une URL canonique HTTPS, un titre, un éditeur et une date
de publication exacte. Pour `2026-10-11..2026-10-17`, les deux bornes sont incluses ;
`2026-10-10` et `2026-10-18` sont exclues. Une date d’événement, d’échéance, de mise
à jour ou un mois sans jour ne prouve pas la date de publication.

Déduplique par URL canonique. Trie les sources valides par date décroissante, puis
selon l’ordre `numerique|ia|commande|rh|bercy`, puis par URL. Attribue ensuite
`U01…UN` sans trou. Le nombre d’articles égale le nombre d’URL uniques.

Utilise uniquement les faits lus dans les sources. Génère de 3 à 5 mots-clés par
article, un `takeaway` et un `snum_interest` courts, sans inventer de fait. À partir
de trois articles, exactement les trois premiers portent `essential=true`. Sous
trois articles, aucun n’est essentiel.

## 3. Appliquer le contrôle final

Avant de rendre le paquet, relis chaque article retenu :

1. retire tout article dont `publication_date_iso` est antérieure à `window_start` ou
   postérieure à `window_end`, même pertinent ;
2. retire toute page de liste, d’accueil, de rubrique, de recherche ou d’agenda :
   l’URL désigne l’article lui-même ;
3. trie les articles restants par date décroissante, puis renumérote `U01…UN` et
   recalcule `essential` ;
4. recompte les articles dont l’URL appartient aux quatorze domaines et écris les
   alertes `watch` avec ces nombres recomptés.

## 4. Appliquer le best effort et rendre le paquet

Une rubrique vide ajoute une alerte `watch`. Moins de cinq articles ajoute aussi une
alerte. Une alerte signale aussi quand moins de cinq articles proviennent des
quatorze domaines. Ces insuffisances ne bloquent jamais le JSON. Si la recherche Web s’est
exécutée mais ne fournit aucune source valide, produis tout de même le paquet avec
`articles=[]`, aucun essentiel et les alertes nécessaires.

Seule une indisponibilité technique réelle du Web arrête le parcours avec
`A_COMPLETER | OUTIL_WEB_INDISPONIBLE | <erreur exacte>`. Une recherche vide n’est
pas une indisponibilité et ne déclenche jamais `A_COMPLETER`.

Applique exactement le schéma du contrat V519. La réponse réussie commence au premier
caractère par `SNUM_PAQUET_RENDU_V519_START`, contient un seul JSON sans bloc de
code, puis `SNUM_PAQUET_RENDU_V519_END` et `PAQUET_RENDU_PRET`. N’affiche aucun
raisonnement, registre, compteur, contrôle intermédiaire, résultat brut ni préambule.

`SNUM_COLLECTE_V523_METHODE_END`
